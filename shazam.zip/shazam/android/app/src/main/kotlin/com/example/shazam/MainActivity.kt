package com.example.shazam

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
